#include <iostream>
#include "Invoice.h"
#include <string>

using namespace std;

int main() {
  Invoice c;//declarando a c a variavel chave
  c.setNumIdentificador("89743984"); //chamando a funçao pra setar o ID
  c.setDescricao("Legal");//chamando a funçao pra setar a descricao
  c.setQtd(34);//chamando a funçao pra setar a quantidade
  c.setPreco(342);//chamando a funçao pra setar o preco
  c.imprime();//chamando a funçao pra imprimir
  
}