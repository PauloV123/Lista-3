#include "Invoice.h"
#include <iostream>
using namespace std;

  Invoice::Invoice(){ //controlador
    numIndetificador = "";
    descricao = "";
    qtd = 0;
    preco = 0; 
  }
  void Invoice::setNumIdentificador(string NovoNumIdent){//funçao pra setar o ID
    numIndetificador = NovoNumIdent;
  }
  void Invoice::setDescricao(string novaDescricao){
    //Funçao pra setar a descricao
    descricao = novaDescricao;
  }
  void Invoice::setQtd(int novaQtd){
    //Funçao pra setar a quantidade
    if(qtd < 0)//if caso a quantidade seja menor que 0
      qtd = 0;
    else //caso seja maior
      qtd = novaQtd;
  }
  void Invoice::setPreco(int novoPreco){
    if(preco < 0)//if caso preco seja menor que 0
      preco = 0;
    else//caso seja maior
      preco = novoPreco;
  }
  
  string Invoice::getNumIdentificador(){//retornando o novo ID
    return numIndetificador;
  }
  string Invoice::getDescricao(){//retornando a nova descricao
    return descricao;
  }
  int Invoice::getQtd(){//retornando a quantidade
    return qtd;
  }
  int Invoice::getPreco(){//retornando o preco
    return preco;
  }
  int Invoice::getInvoiceAmount(){//funçao pra calcular a fatura
    int fatura;
    fatura = qtd*preco;
    if(fatura < 0)
      return 0;
    else
      return fatura;
  }
  void Invoice::imprime(){//funcao pra imprimir os resultados
      cout << "Numero do identificador: " << getNumIdentificador()<< endl;
      cout << "Descricao: " << getDescricao()<< endl;
      cout << "Quantidade:  " << getQtd()<< endl;
      cout << "Preco: " << getPreco()<< endl;
      cout << "Fatura:  " << getInvoiceAmount()<< endl;
    }