#include <string>

using namespace std;

class Invoice{
  //declarando todas as funçoes publicas usada durante o código
  public:
    Invoice();
    string getNumIdentificador();
    
    void setNumIdentificador(string);
    
    string getDescricao();
    
    void setDescricao(string);
    
    int getQtd();
    
    void setQtd(int);
    
    int getPreco();
    
    void setPreco(int);
    
    int getInvoiceAmount();
    
    void imprime();
    
  private: 
  //declarando as variaveis privadas
    string numIndetificador;
    string descricao;
    int qtd;
    int preco;
};
