class Rectangle{
  
  public Rectangle(double lenght, double width){//construtor
    if(lenght > 0 && lenght < 20 && width > 0 && width < 20)
      this.lenght = lenght;
      this.width = width;
    
  }
  //calculando o perimetro
  public double getPerimetro(){
    double soma;
    soma = 2*lenght + 2*width;
    return soma;
  }//calculando a area
  public double getArea(){
    double area;
    area = lenght * width;
    return area;
  }
  //declarando as variaveis private
  private double lenght;
  private double width;
}