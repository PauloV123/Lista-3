class Main {
  public static void main(String[] args) {
    Rectangle R = new Rectangle(2, 4);//chamando a classe Rectangle
    
    //printando os resultados
    System.out.println("Area = " + R.getArea());
    System.out.println("Perimetro = " + R.getPerimetro());
  }
}