public class Rational {
    //construtores
    public Rational() {
        numerator = 1;
        denominator = 1;
    }

    public Rational(int numerator, int denominator) {
        reduce(numerator,denominator);
    }

    public void reduce(int numerator, int denominator){
        int mdc = MDC(numerator,denominator);
        this.numerator = numerator/mdc;
        this.denominator = denominator/mdc;

    }

    public int getNumerator() { //funçao pra retornar o numerador
        return numerator;
    }

    public void setNumerator(int numerator) {
        this.numerator = numerator; // setando o numerador
    }

    public int getDenominator() {
        return denominator; //retornando o denominador
    }

    public void setDenominator(int denominator) {
        this.denominator = denominator; // setando o denominador
    }

    public int MDC(int a, int b) { //funcao MDC
        if (b==0) return a;
        return MDC(b,a%b);
    }

    public void sumRational(Rational a, Rational b){ //funçao de soma 
        int newDenominator = a.getDenominator() * b.getDenominator(); //declarando o novo denominador
        numerator = (newDenominator/a.getDenominator())*a.getNumerator() + (newDenominator/b.getDenominator())*b.getNumerator();
        denominator = newDenominator;
        reduce(numerator,denominator);
    }

    public void subRational(Rational a, Rational b){ // subtraçao do racional
        int newDenominator = a.getDenominator() * b.getDenominator();
        numerator = (newDenominator/a.getDenominator())*a.getNumerator() - (newDenominator/b.getDenominator())*b.getNumerator();
        denominator = newDenominator;
        reduce(numerator,denominator);
    }

    public void multRational(Rational a, Rational b){ //multiplicaçao do racional
        numerator = a.getNumerator()*b.getNumerator();
        denominator = a.getDenominator()*b.getDenominator();
        reduce(numerator,denominator);

    }

    public void divRational(Rational a, Rational b){ // divisao do racional
        numerator = a.getNumerator()*b.getDenominator();
        denominator = a.getDenominator()*b.getNumerator();
        reduce(numerator,denominator);
    }

    public String printRational(){
        return String.format("%d/%d",numerator,denominator);
    }

    public String printFRational(){
        return String.format("%.3f",(float)numerator/denominator);
    }

    private int numerator;
    private int denominator;
}