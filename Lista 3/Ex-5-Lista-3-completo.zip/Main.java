//Paulo Victor R Setubal RA: 22117021-0
class Main {
  public static void main(String[] args) {
    Rational r1 = new Rational(1,2); //Declarando r1 como palavra chave pra funçao Rational
        Rational r2 = new Rational(1,3); //Declarando r2 como palavra chave pra funçao Rational
        Rational r3 = new Rational(); //Declarando r3 como palavra chave pra funçao Rational
        System.out.print("R1: "); 
        System.out.println(r1.printRational()); //printando o R1
        System.out.print("R2: ");
        System.out.println(r2.printRational());//printando o R2

        System.out.print("R1 + R2 = "); //printando soma
        r3.sumRational(r1,r2); 
        //printando r3
        System.out.println(r3.printRational()); 
        System.out.println(r3.printFRational());

        System.out.print("R1 - R2 = "); //subtraçao
      
        r3.subRational(r1,r2);
        //printando a subtraçao
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

        System.out.print("R1 * R2 = "); //multiplicaçao
        r3.multRational(r1,r2);
        //printando a multiplicaçao
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

        System.out.print("R1 / R2 = "); //divisao
        r3.divRational(r1,r2);
        //printando a divisao
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

  }
}