class Main {
  public static void main(String[] args) {
    Rational r1 = new Rational(1,2);
        Rational r2 = new Rational(1,3);
        Rational r3 = new Rational();
        System.out.print("R1: ");
        System.out.println(r1.printRational());
        System.out.print("R2: ");
        System.out.println(r2.printRational());

        System.out.print("R1 + R2 = ");
        r3.sumRational(r1,r2);
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

        System.out.print("R1 - R2 = ");
        r3.subRational(r1,r2);
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

        System.out.print("R1 * R2 = ");
        r3.multRational(r1,r2);
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

        System.out.print("R1 / R2 = ");
        r3.divRational(r1,r2);
        System.out.println(r3.printRational());
        System.out.println(r3.printFRational());

  }
}